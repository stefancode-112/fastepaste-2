# Fastpaste
A minimal Pastebin clone built with FastAPI.